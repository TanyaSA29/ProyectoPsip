package com.uisrael.apipsip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApipsipApplicationTests {

	@Test
	void contextLoads() {
	}

}
